//
//  ViewController.swift
//  FlickrClientApp
//
//  Created by ILKER on 26.06.2023.
//

import UIKit

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

